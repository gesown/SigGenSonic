using UnityEngine;

namespace GitHub.Unity
{
    class RunLocationShim : ScriptableObject
    {
    }
}