﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("IntegrationTests")]
[assembly: AssemblyDescription("GitHub for Unity integration tests")]
[assembly: Guid("1ac3f82e-aeae-4c84-825c-207bb264fcfa")]
