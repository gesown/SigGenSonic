namespace GitHub.Unity
{
    public enum FailureSeverity
    {
        Moderate,
        Critical
    };
}
