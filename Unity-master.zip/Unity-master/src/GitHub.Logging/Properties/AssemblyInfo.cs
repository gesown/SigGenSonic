﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("GitHub.Logging")]
[assembly: AssemblyDescription("GitHub Logging")]
[assembly: Guid("bb6a8eda-15d8-471b-a6ed-ee551e0b3ba0")]
[assembly: InternalsVisibleTo("GitHub.Api", AllInternalsVisible = true)]
[assembly: InternalsVisibleTo("GitHub.Unity", AllInternalsVisible = true)]
