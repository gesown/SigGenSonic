namespace GitHub.Unity
{
    public enum GitConfigSource
    {
        NonSpecified,
        Local,
        User,
        Global
    }
}