﻿namespace GitHub.Unity
{
    public class Organization
    {
        public string Name { get; set; }
        public string Login { get; set; }
    }
}
