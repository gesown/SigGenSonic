﻿using System.Collections.Generic;
using FluentAssertions;
using NUnit.Framework;

namespace GitHub.Unity.Tests
{
    [TestFixture]
    public class MozRootsTests
    {
        [Test]
        public void Test()
        {
            MozRoots.Run();

        }
    }
}