﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("GitHub.Unity")]
[assembly: AssemblyDescription("GitHub for Unity")]
[assembly: Guid("add7a18b-dd2a-4c22-a2c1-488964eff30a")]
