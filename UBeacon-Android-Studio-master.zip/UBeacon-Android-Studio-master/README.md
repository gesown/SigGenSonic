UBeacon-Android-Studio
======================

This is the UBeacon project build for MCI Uni-Stuttgart 

UBeacon build with android studio

&copy; Hanwen Cheng  2015
