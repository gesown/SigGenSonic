﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("GitHub.Api")]
[assembly: AssemblyDescription("GitHub for Unity API")]
[assembly: Guid("4B424108-D0E8-4BF9-9B0C-4FB49E532AB9")]
[assembly: InternalsVisibleTo("GitHub.Unity")]
[assembly: InternalsVisibleTo("GitHub.Unity.45")]
