namespace GitHub.Api
{
    struct WatchArguments
    {
        public string Path;
        public string Filter;
    }
}