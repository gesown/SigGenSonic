﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("UnitTests")]
[assembly: AssemblyDescription("GitHub for Unity unit tests tests")]
[assembly: Guid("69f13d9d-ad56-4eec-ae10-d528ee23e1a9")]
